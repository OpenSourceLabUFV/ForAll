interface ContainerProps {
	name: string;
}

export default ContainerProps;
