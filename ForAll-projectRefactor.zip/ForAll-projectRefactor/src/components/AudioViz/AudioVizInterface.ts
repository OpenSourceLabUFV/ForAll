interface AudioVizProps {
	vizFlag: number;
}

export default AudioVizProps;
