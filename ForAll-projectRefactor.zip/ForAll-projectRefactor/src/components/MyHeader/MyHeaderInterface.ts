interface MyHeaderProps {
	name: String;
}

export default MyHeaderProps
